This is free software distributed under the GNU Affero Public License v 3.0
http://wias-berlin.de/software/tetgen/

sourced from: https://github.com/live-clones/gmsh/tree/master/contrib/Tetgen1.5
08/12/2015

This tool produces tetrahedra from a 'ply' model file
usage: tetgen -pYk [filepath]

Flags and their meanings:
-p enables tetrahedralisation of the mesh
-Y preserves the surface mesh without further subdivision/tesselation
-k is for producing the .vtk file only

